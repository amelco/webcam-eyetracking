Aqui ficam as imagens de saída para treinamento
